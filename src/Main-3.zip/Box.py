class Box:
  # variables
  l= 0.0
  w =0.0
  h =0.0
  # constructor
  def __init__(self):
      self.l = 0.0
      self.w = 0.0
      self.h = 0.0
  # Set methods
  def setL(self, length):
      self.l = length

  def setW(self, width):
      self.w = width

  def setH(self, height):
      self.h = height
  # Get methods
  def getVolume(self):
    return float(self.l)*float(self.w)*float(self.h)

  def getSurfaceArea(self):
      return 2*(float(self.l)*float(self.w))+2*(float(self.l)*(float(self.h)*float(self.h))+2*(float(self.w)*float(self.h)))

