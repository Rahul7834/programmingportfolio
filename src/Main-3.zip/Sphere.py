class Sphere:
  # variables
  radius = 0.0
  # constructor
  def __init__(self):
    self.radius = 0.0
  # Set method
  def setRadius(self, radius):
    self.radius = radius
  # Get methods
  def getVolume(self):
    return (4/3) * 3.1415 * (float(self.radius)**3)

  def getSurfaceArea(self):
    return 4 * 3.1415 * (float(self.radius)**2)
