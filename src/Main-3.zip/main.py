from Box import Box
from Sphere import Sphere
from Pyramid import Pyramid
# Ask user for input
shape = input("Enter the shape (Box, Sphere, Pyramid): ")
value = float(input("Enter the value: "))
# Check user input and perform calculations accordingly
if shape.lower() == 'box':
  box = Box()
  box.setL(value)
  box.setW(value)
  box.setH(value)
  print("Volume of the box:", box.getVolume())
  print("Surface Area of the box:", box.getSurfaceArea())
elif shape.lower() == 'sphere':
  sphere = Sphere()
  sphere.setRadius(value)
  print("Volume of the sphere:", sphere.getVolume())
  print("Surface Area of the sphere:", sphere.getSurfaceArea())
elif shape.lower() == 'pyramid':
  pyramid = Pyramid()
  pyramid.setL(value)
  pyramid.setW(value)
  pyramid.setH(value)
  print("Volume of the pyramid:", pyramid.getVolume())
  print("Surface Area of the pyramid:", pyramid.getSurfaceArea())
else:
  print("Invalid shape!")
